<style>
    @import url('https://fonts.googleapis.com/css2?family=Open+Sans:wght@400;600&display=swap');

    body {
        font-family: 'Open Sans', Arial, sans-serif;
    }

    .car-cover {
        width: 10em;
    }

    .car-item .col-auto {
        max-width: calc(100% - 12em) !important;
    }

    .car-item:hover {
        transform: translate(0, -4px);
        background: #a5a5a521;
    }

    .banner-img-holder {
        height: 25vh !important;
        width: calc(100%);
        overflow: hidden;
    }

    .banner-img {
        object-fit: scale-down;
        height: calc(100%);
        width: calc(100%);
        transition: transform .3s ease-in;
    }

    .car-item:hover .banner-img {
        transform: scale(1.3)
    }

    .welcome-content {
        font-family: 'Open Sans', Arial, sans-serif;
        font-size: 14px;
        color: #333;
        line-height: 1.6;
    }

    .welcome-content h3 {
        font-weight: 600;
        text-align: center;
        color: #6B2BD9; /* purple heading like image */
        font-size: 24px;
        margin-bottom: 0.5em;
        position: relative;
    }

    .welcome-content h3::after {
        content: '';
        display: block;
        margin: 0.3em auto 0;
        width: 40px;
        height: 3px;
        background: #00D1CF; /* turquoise underline */
        border-radius: 2px;
    }

    .welcome-content p {
        margin-bottom: 1em;
        text-align: justify;
    }

    .highlight {
        background-color: #FFE484; /* yellow */
        font-weight: 600;
        padding: 0.1em 0.4em;
        border-radius: 4px;
    }

    .card-3d {
        background: white;
        border-radius: 12px;
        padding: 1.5em;
        box-shadow:
            0 10px 20px rgba(0, 0, 0, 0.2),
            0 6px 6px rgba(0, 0, 0, 0.15),
            0 0 0 1px rgba(0, 0, 0, 0.05);
        transition: transform 0.3s ease, box-shadow 0.3s ease;
    }

    .card-3d:hover {
        transform: translateY(-6px);
        box-shadow:
            0 14px 28px rgba(0, 0, 0, 0.25),
            0 10px 10px rgba(0, 0, 0, 0.22);
    }

    .cta-button {
        display: inline-block;
        margin-top: 1.5em;
        padding: 0.8em 1.6em;
        background: linear-gradient(to right, #814CFC, #00D1CF);
        color: white;
        font-weight: bold;
        border: none;
        border-radius: 25px;
        text-align: center;
        font-size: 14px;
        transition: background 0.3s ease;
        text-decoration: none;
    }

    .cta-button:hover {
        opacity: 0.9;
    }
</style>

<div class="col-lg-12 py-5">
    <div class="contain-fluid">
        <div class="card-3d">
            <h3>Welcome</h3>
            <hr>
            <div class="welcome-content">
                <p>
                    <span class="highlight">Welcome to MovieMatch</span>, your ultimate destination for discovering amazing 
                    movies tailored to your unique taste! Whether you’re in the mood for a thrilling adventure, 
                    a heartwarming romance, a laugh-out-loud comedy, or an edge-of-your-seat drama, we’re here 
                    to help you find the perfect film.
                </p>

                <p>
                    At MovieMatch, we take your preferences seriously—simply tell us about your favorite genres, 
                    movies, or actors, and we’ll provide personalized recommendations just for you.
                </p>

                <p>
                    Our platform is designed to make your movie selection process effortless and enjoyable, so you can 
                    spend less time searching and more time watching.
                </p>

                <p>
                    Dive into a world of cinematic treasures and start your movie journey today. 
                    Lights, camera, action—let’s find your next favorite film!
                </p>

                <a href="#" class="cta-button">Join 5M+ users finding their perfect movie!</a>
            </div>
        </div>
    </div>
</div>
