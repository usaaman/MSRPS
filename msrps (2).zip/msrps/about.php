<div class="col-12">
    <div class="row justify-content-center my-4">
        <div class="col-md-8 col-lg-6">
            <div class="card border-0" style="
                background-color: #f8f9fa;
                border-radius: 12px;
                box-shadow: 0 8px 20px rgba(0, 0, 0, 0.08);
            ">
                <div class="card-body p-4">
                    <h2 class="text-center mb-3" style="
                        color: #6f42c1;
                        font-weight: 600;
                        position: relative;
                        text-shadow: 1px 1px 2px rgba(111, 66, 193, 0.2);
                    ">
                        About MovieMatch
                        <div class="mx-auto" style="
                            width: 50px;
                            height: 3px;
                            background: linear-gradient(90deg, #6f42c1, #0dcaf0);
                            margin-top: 8px;
                            border-radius: 3px;
                            box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
                        "></div>
                    </h2>

                    <div class="px-2" style="font-size: 1rem; line-height: 1.6;">
                        <p class="mb-3">
                            <span class="d-inline-block px-2 py-1 mb-1" style="
                                background: #fff3cd;
                                color: #000;
                                font-weight: 600;
                                border-radius: 6px;
                                box-shadow: 0 2px 4px rgba(0, 0, 0, 0.05);
                            ">
                                Who We Are
                            </span>
                            Founded in 2023, MovieMatch is a team of film enthusiasts and tech innovators dedicated to revolutionizing how people discover movies. Our platform serves millions of users worldwide.
                        </p>

                        <p class="mb-3">
                            <span class="d-inline-block px-2 py-1 mb-1" style="
                                background: #e2f0fd;
                                color: #000;
                                font-weight: 600;
                                border-radius: 6px;
                                box-shadow: 0 2px 4px rgba(0, 0, 0, 0.05);
                            ">
                                Our Technology
                            </span>
                            Using AI-powered algorithms and user preferences, we analyze thousands of films to deliver personalized recommendations. Our system learns from your ratings to refine suggestions over time.
                        </p>

                        <p class="mb-3">
                            <span class="d-inline-block px-2 py-1 mb-1" style="
                                background: #d1fae5;
                                color: #000;
                                font-weight: 600;
                                border-radius: 6px;
                                box-shadow: 0 2px 4px rgba(0, 0, 0, 0.05);
                            ">
                                What Makes Us Unique
                            </span>
                            Unlike traditional review sites, we focus on <strong>mood-based matching</strong>. Tell us how you feel, and we'll find films to match—whether you want excitement, inspiration, or relaxation.
                        </p>

                        <div class="text-center mt-4">
                            <span class="d-inline-block px-3 py-2" style="
                                background: linear-gradient(90deg, #6f42c1, #0dcaf0);
                                color: white;
                                font-weight: 500;
                                border-radius: 30px;
                                box-shadow: 0 6px 12px rgba(111, 66, 193, 0.25);
                            ">
                                Join 5M+ users finding their perfect movie!
                            </span>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>