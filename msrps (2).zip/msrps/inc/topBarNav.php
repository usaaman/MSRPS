<style>
  /* Top strip modern with enhanced visuals */
  #login-nav {
    position: fixed !important;
    top: 0 !important;
    z-index: 1037;
    padding: 1.3em 2.5em !important; /* More padding for taller height */
    min-height: 90px; /* More height for the strip */
    width: 100%;
    background: linear-gradient(90deg, #1e3c72, #2a5298); /* Deep blue gradient */
    color: white;
    border-bottom-left-radius: 1rem;
    border-bottom-right-radius: 1rem;
    box-shadow: 0 6px 15px rgba(0, 0, 0, 0.25); /* Stronger shadow for depth */
    font-size: 0.95rem;
    position: relative;
    overflow: hidden;
  }

  /* Optional: light gradient shimmer overlay */
  #login-nav::before {
    content: "";
    position: absolute;
    top: 0;
    left: -50%;
    width: 200%;
    height: 100%;
    background: linear-gradient(
      120deg,
      rgba(255, 255, 255, 0.05) 0%,
      rgba(255, 255, 255, 0.1) 20%,
      rgba(255, 255, 255, 0.05) 40%,
      transparent 100%
    );
    animation: shine 7s linear infinite;
    pointer-events: none;
  }

  @keyframes shine {
    0% {
      transform: translateX(0%);
    }
    100% {
      transform: translateX(100%);
    }
  }

  #login-nav span,
  #login-nav i {
    color: white;
  }

  #login-nav a {
    color: white !important;
    background-color: #0052cc;
    padding: 6px 16px;
    margin-left: 10px;
    border-radius: 30px;
    font-weight: 600;
    transition: all 0.3s ease-in-out;
    text-decoration: none;
    display: inline-block;
  }

  #login-nav a:hover {
    background-color: #003d99;
    text-decoration: none;
    color: #fff !important;
  }
  

<!-- Navbar Important -->
    
        #login-nav {
          position: fixed !important;
          top: 0 !important;
          z-index: 1037;
          padding: 0.3em 2.5em !important;
        }
        #top-Nav{
          top: 2.3em;
        }
        .text-sm .layout-navbar-fixed .wrapper .main-header ~ .content-wrapper, .layout-navbar-fixed .wrapper .main-header.text-sm ~ .content-wrapper {
          margin-top: calc(3.6) !important;
          padding-top: calc(3.2em) !important
      }
      </style>
      <nav class="w-100 px-2 py-1 position-fixed top-0 bg-light text-dark" id="login-nav">
        <div class="d-flex justify-content-between w-100">
          <div>
            <span class="mr-2"><i class="fa fa-phone mr-1"></i> <?= $_settings->info('contact') ?></span>
          </div>
          <div>
            <?php if($_settings->userdata('id') > 0): ?>
              <span class="mx-2"><img src="<?= validate_image($_settings->userdata('avatar')) ?>" alt="User Avatar" id="student-img-avatar"></span>
              <span class="mx-2">Howdy, <?= !empty($_settings->userdata('username')) ? $_settings->userdata('username') : $_settings->userdata('email') ?></span>
            <?php if($_settings->userdata('login_type') == 1): ?>
              <span class="mx-1"><a href="<?= base_url.'classes/Login.php?f=logout' ?>"><i class="fa fa-power-off"></i></a></span>
            <?php else: ?>
              <span class="mx-1"><a href="<?= base_url.'classes/Login.php?f=client_logout' ?>"><i class="fa fa-power-off"></i></a></span>
            <?php endif; ?>
            <?php else: ?>
              <a href="./register.php" class="mx-2 text-dark">Register</a>
              <a href="./login.php" class="mx-2 text-dark">User Login</a>
              <a href="./admin" class="mx-2 text-dark">Admin Login</a>
            <?php endif; ?>
          </div>
        </div>
      </nav>
      <nav class="main-header navbar navbar-expand navbar-dark border-0 text-sm bg-gradient-lightblue" id='top-Nav'>
        
        <div class="container">
          <a href="./" class="navbar-brand">
            <img src="<?php echo validate_image($_settings->info('logo'))?>" alt="Site Logo" class="brand-image img-circle elevation-3" style="opacity: .8">
            <span><?= $_settings->info('short_name') ?></span>
          </a>

          <button class="navbar-toggler order-1" type="button" data-toggle="collapse" data-target="#navbarCollapse" aria-controls="navbarCollapse" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
          </button>

          <div class="collapse navbar-collapse order-3" id="navbarCollapse">
            <!-- Left navbar links -->
            <ul class="navbar-nav">
              <li class="nav-item">
                <a href="./" class="nav-link <?= isset($page) && $page =='home' ? "active" : "" ?>">Home</a>
              </li>
              <li class="nav-item">
                <a href="./?page=movies" class="nav-link <?= isset($page) && $page =='movies' && !isset($_GET['gid']) && !isset($_GET['search']) ? "active" : "" ?>">All Movies</a>
              </li>
              <li class="nav-item dropdown">
                <a id="dropdowngenremenu" href="#" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" class="nav-link dropdown-toggle">Genres</a>
                <ul aria-labelledby="dropdowngenremenu" class="dropdown-menu border-0 shadow">
                  <?php 
                  $i = 0;
                  $genre_qry = $conn->query("SELECT * FROM `genre_list` order by `name` asc");
                  while($row = $genre_qry->fetch_assoc()):
                    $i++;
                  ?>
                  <li><a href="./?page=movies&genre=<?= urlencode($row['name']) ?>&gid=<?= $row['id'] ?>" class="dropdown-item"><?= $row['name'] ?></a></li>
                  <?php if($i < $genre_qry->num_rows): ?>
                  <li class="dropdown-divider"></li>
                  <?php endif; ?>
                  <?php endwhile; ?>
                </ul>
              </li>
              <li class="nav-item">
                <a href="./?page=about" class="nav-link <?= isset($page) && $page =='about' ? "active" : "" ?>">About Us</a>
              </li>
              <li class="nav-item">
                <a href="./?page=contact_us" class="nav-link <?= isset($page) && $page =='contact_us' ? "active" : "" ?>">Contact Us</a>
              </li>
              <?php if($_settings->userdata('id') > 0 && $_settings->userdata('login_type' != 1)): ?>
              <li class="nav-item">
                <a href="./?page=profile" class="nav-link <?= isset($page) && $page =='profile' ? "active" : "" ?>">Profile</a>
              </li>
              <?php endif; ?>
              <!-- <li class="nav-item">
                <a href="#" class="nav-link">Contact</a>
              </li> -->
            </ul>

            
          </div>
          <!-- Right navbar links -->
          <div class="order-1 order-md-3 navbar-nav navbar-no-expand ml-auto">
          </div>
        </div>
      </nav>
      <!-- /.navbar -->
      <script>
        $(function(){
          
        })
      </script>